# My API Server with Tests

## 🚀 API Overview
This project includes a simple Node.js + Express API with a `/api/hello` endpoint and test coverage using Jest.

## 🛠 Tech Stack
- Node.js
- Express
- Jest
- Supertest

## 📦 How to Run

```bash
npm install
npm run start     # or node server.js
npm test          # run tests + show coverage
```

## ✅ Test Coverage

> Run `npm test` and open `coverage/lcov-report/index.html` to view a detailed report.
